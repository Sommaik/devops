export class Customer {
    custCode : string;
    custName : string;
    compCode : string;
    compName : string;
}
